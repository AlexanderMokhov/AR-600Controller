extern "C" void gcontrol(double t, double* xin, double* xout, double* par)
{
}
